#include<iostream>
#include<stdlib.h>
using namespace std;

int main()
{
// Declare variable ans (single character) to hold the user's answer to the question
    char ans;
// Declare variable age (whole number) to hold the user's age
    int age;
// Declare variable correct (boolean value) to implement the flag
    bool correct;
    correct =true;
    
// Ask the user a yes/no question and make sure the response is

  
// either y or n using a FLAG-CONTROLLED LOOP
while(correct)
{
  cout<<"Do you like icecream?(y / n): ";
	
cin>>ans ;
{
 cin.clear();
 cin.ignore(2000, '\n');
  }
	if(ans == 'y' || ans=='n')
  {
	cout<<"What is your age: ";
	cin>>age;
		if ( !cin ){
 cin.clear();
 cin.ignore(2000, '\n');
 }
 correct = false;
  }
 else
{
cout<<"Invalid input"<< endl;
	correct = true;
 		system("pause");
		system("cls");
 

  }
 

}

 

    
    
// Get the user's age
// Make sure the user enters her age as a number using a FLAG-CONTROLLED LOOP
    
    

    cout << "Thanks for your input!" << endl;
    
    return 0;
}