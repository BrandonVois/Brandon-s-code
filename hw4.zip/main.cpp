//******************************************************************************
// Team # CSCI 1370 Spring 2021 Homework # 4
// Brandon Rubio
// Jose Gonzalez
// Calculates some measurements involving a squares
//
//******************************************************************************
//CLIENT PROGRAM THAT WORKS WITH SQUARES

#include <iostream>
#include <fstream>

// include the header file for squares
/*your code here*/
#include "my.square.h"



using namespace std;

int main()
{
	ifstream inFile;
	int s1, s2, s3;		// declare three int variables
	// declare 4 objects of type square named sq1, sq2, sq3, and sq4 initializing the third one to 10
  square sq1;
  square sq2;
  square sq3 = 10;
  square sq4;

	/*your code here*/

	inFile.open("input_hw4.txt");
	if(!inFile)
	{
		cout << "Could not open input file!" << endl;
		system("pause");
		return 1;
	}

	// Access members using dot operator
	cout << "Before assigning values to the squares their sides are:" << endl;
	cout << "Square 1: " << sq1.getSide() << endl;		// Show the initial side of Square 1
	cout << "Square 2: " << sq2.getSide()<< endl;		// Show the initial side of Square 2
	cout << "Square 3: " << sq3.getSide()<< endl;		// Show the initial side of Square 3
	cout << endl << "............Starting to process the file............" << endl << endl;
	inFile >> s1 >> s2 >> s3;								// read 3 sides from the file (priming read)
	while(inFile)
	{
		cout << "Storing the values read into the side of squares..." << endl << endl;
		sq1.setSide(s1);
		sq2.setSide(s2);
		sq3.setSide(s3);
		cout << "Displaying the new side of squares" << endl;
		cout << "Square 1: " << sq1.getSide() << endl;		// Show the new side of Square 1
		cout << "Square 2: " << sq2.getSide() << endl;		// Show the new side of Square 2
		cout << "Square 3: " << sq3.getSide() << endl;		// Show the new side of Square 3
		cout << endl << "Testing other member functions" << endl << endl;
		cout << "Area of Square 1: " << sq1.area() << endl;				// show the area of Square 1
		cout << "Perimeter of Square 2: " << sq2.perimeter()<< endl;		// show the perimeter of Square 2
		if(sq1.equalTo(sq3))													// if Square 1 is equal to Square 3
			cout << "Square 1 and Square 3 are equal" << endl;
		else
			cout << "Square 1 and Square 3 are not equal" << endl;

		cout << "Area of (Square 2 + Square 3): " << sq2.plus(sq3)  << endl;	// Add the areas of Square 2 and Square 3

		cout << "Creating a square double the size of Square 1" << endl;
		sq4=sq1.increaseBy(2);								// Create a square with double the side of Square 1 and assign it to Square 4
		cout << "The side of the new square: " << sq4.getSide() << endl;		// Show the side of Square 4

		cout << endl << "..........Done with this set of values :-).........." << endl << endl;

		inFile >> s1 >> s2 >> s3;	// read next set of 3 sides
	}
	inFile.close();
	system("pause");
	return 0;
}
