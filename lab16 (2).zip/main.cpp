#include<iostream>


// Include here the libraries that your program needs to compile
#include<fstream>
#include<string>
#include<iomanip>

using namespace std;

// Insert here your function prototype
void print_occupancy(ifstream& inputFile,double occ,int roomcount,int total,double rate,double rt,int floorcount,int totalf);


int main()
{
  int numrooms;
 int occupancy; 
  int total;
  double rate;
  double rq;
  numrooms =0;
  int floorcount;
  int totalf;

// Enter here all the statements needed to use the input file'
ifstream inFile;
inFile.open("occupants.txt");
// Check if there was an error opening the input file
if (inFile.fail())
{
  cerr<<"Error opening the file";
}
cout<<setw(5)<<"Floor"<<setw(5)<<"l "<<setw(8)<<"occupants"<<setw(10)<<"rates(%)"<< endl;
cout<<"-----------------------------"<<endl;
// Call the function to print the occupancy table
print_occupancy(inFile,occupancy,numrooms,total,rate, rq,floorcount,totalf);


// Close the input file
inFile.close();
	return 0;



}

//************************  Function definitions  *************************
// Read the handout carefully for detailed description of the functions that you have to implement


// This function receives an input file with data about rooms in a hotel.
// Each row of the file represents a floor in the hotel. You do not know ahead of time how many floors there are in the hotel.
// Each room is represented by a single digit: 1 (the room is occupied) or 0 (the room is not occupied).
// Because each floor can have a different number of rooms, the value -1 is used to indicate that the end of data for that floor has been reached.
// The function must print the header of the table followed by the floor number, the number of rooms occupied in that floor, and the occupancy
// rate (percentage of rooms occupied) for that floor. Below this information it must display the overall occupancy rate for the whole hotel.
// The rates must be displayed real numbers with a single decimal digit.


void print_occupancy(ifstream& inputFile,double occ,int roomcount,int total,double rate,double rt,int floorcount,int totalf)
{
floorcount =1;

  for(total = 0; !inputFile.eof();floorcount++)
  {
    total =0;
    roomcount =0;


    while(occ != -1)
		{
     
      ++roomcount;
      inputFile>>occ;
      total= occ+total;
      totalf=total;
     
      cout<<fixed<<setprecision(1);
    
    
    }
    
    total= total +1;
    roomcount = roomcount -1;
     rate= (static_cast<double>(100) * static_cast<double>(total)) /static_cast<double>(roomcount);
     rt =static_cast<double>(rate) + static_cast<double>(rt);
    cout<<setw(5)<<floorcount<<setw(5)<<" :  "<<setw(8)<< total <<setw(10)<<rate<< endl;
    cout<<fixed<<setprecision(1);
    occ = 0;
    
     
  

  }
 

  rt = (static_cast<double>(rt) / static_cast<double>(roomcount));
  cout<<"-----------------------------"<< endl;
cout<<"The overall occupancy rate is: " <<rt<<" %"<<endl;


}
