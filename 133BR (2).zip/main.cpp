#include<iostream>
#include <iomanip>  
using namespace std;

int main()
{
// Declare variable grade (whole number) to hold the grade entered by the user 
int  grade;
// Declare and initialize variable sum (whole number) to accumulate the grades entered by the user
int sum;
sum=0;
// Declare and initialize variable count (whole number) to count the grades entered by the user
int count;
count=0;

// Declare variable avg (real number) to hold the calculated average
double avg;
while(grade >= 0 )
{
  cout<<"Enter a grade or a negative value to stop: ";
  cin>>grade;
  if(grade <= -1)
  {
  grade = -1;
 
  }
  else
  sum= grade+sum;
  count++;
}  


// Use a SENTINEL-CONTROLLED LOOP to process grades until a negative value (the sentinel) is entered
// Each time through the loop, accumulate the number input by the user
// in sum. Make sure not to include the sentinel value in the sum or count!


count= count -1;
avg= static_cast<double>(sum) / static_cast<double>(count);
// Calculate the average of the grades entered by the user (avoid division by zero)
	
// Print the result in fixed format with 1 decimal digit
cout<<fixed<<setprecision(1);
cout<<"The average is: "<<avg;
   
    return 0;
}