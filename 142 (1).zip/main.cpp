/////////////////////////////////////////////////////////////////////
//
// Name: <Brandon Rubio>
// Date: <March 29, 2021>
// Class: <Your class number and section number, like: CSCI 1370.02>
// Semester: <This semester, like: Spring 2012>
// CSCI/CMPE 1370 Instructor: <Your lecture instructor's name>
//
// Search a dictionary file for the word input by the user.
//
/////////////////////////////////////////////////////////////////////

#include<iostream>
#include<string>
#include<fstream>

using namespace std;

int main()
{
    string word; // The word entered by the user
    string result; // The word read from the file
    int counter = 0; // Counts the number of lines read from the file
    bool found = false; // To determine if the user's word has been found
    ifstream file; // The input file

    
    ///////////////////////////////////
    // Start of your code
    
    //open the dictionary file.
    
    file.open("dictionary.txt");
   
    //ask the user to input the word they want to search for.
    cout<<"Enter a word to search for in the dictionary: ";
    cin>>word;
    cout<<endl;

    // Use a while loop to loop through the file.
    // Use break to stop the loop if the word is found

    while(word != result){
      file>>result;
      counter++;
      if(counter == 80369)
      {
        cout<<"Your word is not on the dictionary"<<endl;
        break;
      }
      else{


      }

      
    }
  if(counter == 80369)
  {
    cout<<endl;
  }
  else{
	cout<<"Your word was found in line: "<<counter;
  }
    // If the word is not found display a message.


    
    
    
    // End of your code
    ///////////////////////////////////
    
    
    //system("pause");
    return 0;
}