#include <iostream>

// Include here the libraries that your program needs to compile
#include <fstream>
#include <cmath>
#include <iomanip>


using namespace std;

// Insert here your function prototypes
void   getData(ifstream& iFile,ifstream & inputb, string students[], int grades[], ofstream & fout);
int getMax(int grades[]);
void  Printdata (ifstream& iFile,ifstream & inputb, string students[], int grades[], ofstream & fout,int hi);
 int curveGrade(int grades,int hi);





// Declare here constant MAX
const int MAX = 41;


int main()
{
	// Declare all the variables that will be used to process the data
  ofstream out;
  ifstream inFile;
  ifstream inf;
  int grade[MAX];
  string name[MAX];
  int higuest;
  int curved[MAX];

	// Open the files ensuring they are opened
	inFile.open("input18.txt");if (! inFile){cout << "File not found!" << endl << endl;}
  inf.open("input18b.txt");if (! inf){cout << "File not found!" << endl << endl;}
  out.open("output18.txt");if (! out){cout << "File not found!" << endl << endl;}
	// Call the functions to process the data
 getData(inFile,inf,name,grade,out);
 higuest=getMax(grade);
 Printdata (inFile,inf,name,grade,out,higuest);
 
 
 





	// Close the files

inf.close();
inFile.close();
out.close();
	return 0;
}


//************************  Function definitions  *************************
// Read the handout carefully for detailed description of the functions that you have to implement


// Receives the input file, the array of students’ names, and the array of students’ grades.
// It reads the input data from the file into the corresponding arrays and returns them along
// with the quantity of students processed to main().Although there should be no more than 40
// students this function must ensure that if the file has more than 40 records it reads only
// the first 40 and displays a warning on the screen indicating that the maximum has been exceeded.
void   getData(ifstream& iFile,ifstream & inputb, string students[],  int grades[],ofstream & fout)
{
  int i;
  i=0;
  while(i<=MAX)
  {
   
    if(i==40)
  {
      fout<<"Max number of inputs has been reached"<< endl;
      break;
  }
  else if(!iFile.eof())
  {
    ++i;//adds plus 1
   iFile>>students[i]>>grades[i];//takes in file and stores it into array based on the number of i
     if(iFile.eof())
    {
      --i;
      continue;
    }
  
  }
  else if(iFile.eof())
  {
    ++i;
    inputb>>students[i]>>grades[i];
  }
 
}
}


// Receives the array of students’ grades and the quantity of grades to process. It determines
// and returns to main() the highest grade among the students.
int getMax(int grades[])
{
  int i;
   for(i = 1;i < MAX; ++i)
    {
      
       if(grades[0] < grades[i])
          grades[0] = grades[i];
    }
   return grades[0];
    
}



// Receives the output file, the array of students’ names, the array of students’ grades, the
// quantity of students to process, and the highest grade among the students.It prints the output
// to the output file as shown in Figure 2. This function must call a function named curveGrade()
// to get the values for the curved grades(curved grade = actual grade / highest grade * 100).
void  Printdata (ifstream& iFile,ifstream & inputb, string students[], int grades[], ofstream & fout,int hi)
{ 
  fout<<setw(10)<<right<<"NAME"<<setw(10)<<right<<"GRADE"<<setw(10)<<right<<"CURVE"<<setw(15)<<right<<"GRAPH"<<endl;
  int i;
  int cu[41];
  for(i = 1;i < MAX; ++i)
  {
     cu[i]=curveGrade(grades[i],hi);
    fout<<setw(10)<<right<<students[i]<<setw(10)<<right<<grades[i]<<setw(10)<<right<<cu[i]<<" "<<setw(15)<<right;
if(cu[i]>=95)
{
fout<<"**********"<<endl;
}
else if(cu[i]>=85)
{
fout<<"*********"<<endl;
}
else if(cu[i]>=75)
{
fout<<"********"<<endl;
}
else if(cu[i]>=65)
{
  fout<<"*******"<<endl;
}
else if(cu[i]>=55)
{
  fout<<"******"<<endl;
}
else if(cu[i]>=45)
{
  fout<<"*****"<<endl;
}
else if(cu[i]>=35)
{
  fout<<"****"<<endl;
}
else if(cu[i]>=25)
{
  fout<<"***"<<endl;
}
else if(cu[i]>=15)
{
  fout<<"**"<<endl;
}
else if(cu[i]>=5)
{
  fout<<"*"<<endl;
}
else if(cu[i]<5)
fout<<"u get no stars ur too dumb bro"<< endl;
  }

}

// Receives the actual and the highest grades and returns the curved grade. Since the arguments that
// it receives are whole numbers, the result of the division must be rounded off to the ones before 
// it is returned by the function.
 int curveGrade(int grades,int hi)
 {
   double i;
   i=0;

   i=(static_cast<double>(grades)/static_cast<double>(hi))*100.;
 return i;

 }
