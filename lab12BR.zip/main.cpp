/////////////////////////////////////////////////////////////////////
//
// Name: <Brandon Rubio>
// Date: <3/18/2021>
// Class: < 1370 and 91L, like: CSCI 1370.91L>
// Semester: <spring 2021>
// CSCI/CMPE 1370 Instructor: <Mr. Gustavo Dietrich>
//
// Program Description: Ask the 8 ball a question
//
/////////////////////////////////////////////////////////////////////

#include <iostream>				// to use cin and cout
#include <typeinfo>				// to be able to use operator typeid

// Include here the libraries that your program needs to compile



using  namespace  std;

// Ignore this; it's a little function used for making tests
inline void _test(const char* expression, const char* file, int line)
{
	cerr << "test(" << expression << ") failed in file " << file;
	cerr << ", line " << line << "." << endl << endl;
}
// This goes along with the above function...don't worry about it
#define test(EXPRESSION) ((EXPRESSION) ? (void)0 : _test(#EXPRESSION, __FILE__, __LINE__))

// Insert here the prototypes of the functions
int randNumGen(int lowrange,int highrange) ;
string fortuneTellerA(int randomnumber) ;
string fortuneTellerB(int ran);


int main()
{
	// Declare a variable named randomNumber that holds whole numbers
  int randomNumber;

	// Declare a variable named lowRange that holds whole numbers and initializes it to 
 int lowRange= 0;

	// Declare a variable named highRange that holds whole numbers and initializes it to 4
  int highRange = 4;


	// Seed the random number generator using expression 1) on my handoutsrand(static_cast<int> (time(NULL)));
  srand(static_cast<int> (time(NULL)));

	// Prompt the user to enter a question
  cout<< "Ask a question to the eight ball: " ;

	// Ignore the user input
  cin.ignore();

	// Call function randNumGen() to generate a random number and assign it to randomNumber
  randomNumber = randNumGen(lowRange,highRange);

	// Display title "Part A solution"
  cout<<"Part A solution "<< endl;
	// Display the message shown below
	//	"Answer: “, call function fortuneTellerA() to get the answer
  cout<<"Answer: "<< fortuneTellerA(randomNumber)<< endl;

	// Display title "Part B solution"
  cout<<"Part B solution"<<endl;

	//Displays the message shown below
	//	"Answer: “, call function fortuneTellerB() to get the answer
  cout<<"Answer: "<< fortuneTellerB(randomNumber)<< endl;


	system("pause");

	// Do NOT remove or modify the following statements
	cout << endl << "Testing your solution" << endl << endl;

	test(randomNumber >= 0 && randomNumber <= 4);			// Incorrect random number (out of range)

	test(fortuneTellerA(0) == "Yes");						// Incorrect answer
	test(fortuneTellerA(1) == "Maybe");						// Incorrect answer
	test(fortuneTellerA(2) == "No");						// Incorrect answer
	test(fortuneTellerA(3) == "Ask again later");			// Incorrect answer
	test(fortuneTellerA(4) == "I don't know");				// Incorrect answer
	test(fortuneTellerA(14) == "I don't know");				// Incorrect answer

	test(fortuneTellerB(0) == "Yes");						// Incorrect answer
	test(fortuneTellerB(1) == "Maybe");						// Incorrect answer
	test(fortuneTellerB(2) == "No");						// Incorrect answer
	test(fortuneTellerB(3) == "Ask again later");			// Incorrect answer
	test(fortuneTellerB(4) == "I don't know");				// Incorrect answer
	test(fortuneTellerB(14) == "I don't know");				// Incorrect answer

															// To pause the execution of the program
	cout << "Press Enter to continue ...";
	cin.ignore(100, '\n');
	cin.get();

	return 0;
}

//************************  Function definitions  *************************
 int randNumGen(int lowrange,int highrange) ;
 string fortuneTellerA(int randomnumber) ;
 string fortuneTellerB(int ran);
// Read the handout carefully for detailed description of the functions that you have to implement

// This function generates a random number within a specified range.
// It receives two whole numbers : the first one is the upper boundary and
// the second one is the lower boundary used to generate the random number.
// Returns the random number generated using expression 2) on my handout

 int randNumGen(int lowrange,int highrange) 
{
  return ( rand() % (highrange - lowrange + 1) ) + lowrange ;
}




// Thisfunction uses multi - branch if - else statements to determine the answer to be 
// returned based on the number received.
// It receives the random number(whole number) and returns the corresponding answer
// based on the table shown on my handout
//
// Important: in this solution make your function directly return the answer in each
// branch of the multi - branch if - else statements.

 string fortuneTellerA(int randomnumber) 
 {
   if( randomnumber== 0)
   return "Yes" ;
   else if (randomnumber == 1)
   return "Maybe";
   else if( randomnumber== 2)
   return "No";
   else if( randomnumber== 3)
   return "Ask again later";
   else 
   return "I don't know";
 }



// Thisfunction uses switch statements to determine the answer to be 
// returned based on the number received.
// It receives the random number(whole number) and returns the corresponding answer
// based on the table shown on my handout
//
// Important: in this solution declare a local variable that holds text and assign
// the corresponding answer in each case of the switch statement. Upon exiting the
// switch return the value in the local variable.
string fortuneTellerB(int ran)
{
  switch(ran)
  {
  case 0:
  return "Yes";
  break;
  case 1:
  return "Maybe";
  break;
  case 2:
  return "No";
  break;
  case 3:
  return "Ask again later";
  break;
  default:
  return "I don't know";

}


}