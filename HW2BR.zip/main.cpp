//******************************************************************************
// Team # CSCI 1370 Spring 2021 Homework # 2
// Brandon Rubio
//Jose Gonzalez
//Gets the area of points and then 
//
//******************************************************************************

#include <iostream>				// to use cin and cout
#include <typeinfo>				// to be able to use operator typeid

// Include here the libraries that your program needs to compile
#include <fstream>
#include <math.h>
#include <iomanip> 

using  namespace  std;

// Ignore this; it's a little function used for making tests
inline void _test(const char* expression, const char* file, int line)
{
	cerr << "test(" << expression << ") failed in file " << file;
	cerr << ", line " << line << "." << endl << endl;
}
// This goes along with the above function...don't worry about it
#define test(EXPRESSION) ((EXPRESSION) ? (void)0 : _test(#EXPRESSION, __FILE__, __LINE__))

// Insert here the prototypes of the functions
double round_off(double x,int digits);
void getPoint(ifstream& inputFile, double& x, double& y );
double calcLength(double x11,double y11,double x22,double y22);
double semiPerimeter(double l1,double l2,double l3);
double calcArea(double ab,double bc, double ca);
void print_Distance(ofstream& outputFile,double x1,double y1,double x2, double y2,double DB);

int main()
{
double x1,y1,x2,y2,x3,y3,abR,bcR,caR,Area; 
x1=0;
y1=0;
x2=0;
y2=0;
x3=0;
y3=0;

ifstream inFile;
ofstream outFile;


inFile.open("inputhw2.txt");
outFile.open("outputhw2.txt");

getPoint(inFile,x1,y1);
getPoint(inFile,x2,y2);
getPoint(inFile,x3,y3);


abR=calcLength(x1,y1,x2, y2);
bcR=calcLength(x2,y2,x3,y3);
caR=calcLength(x3,y3,x1, y1);

Area=calcArea(abR, bcR, caR);

print_Distance(outFile, x1, y1, x2,  y2, abR);
print_Distance(outFile, x2,y2, x3,  y3, bcR);
print_Distance(outFile, x1, y1, x3,  y3, caR);

outFile<<"The area of this triangle is: "<<Area;




inFile.close();
outFile.close();











	
	
// Do NOT remove or modify the following statements

// To pause the execution of the program
	cout << "Press Enter to continue ...";
	cin.get();

	cout << endl << "Testing your solution" << endl << endl;

	test(fabs(round_off(calcLength(1.0, 1.2, 6.0, 6.1), 2) - 7.00) < .001);			// Incorrect calculation of length
	test(fabs(round_off(calcLength(6.0, 6.1, 3.2, 6.5), 2) - 2.83) < .001);			// Incorrect calculation of length
	test(fabs(round_off(calcLength(1.0, 1.2, 3.2, 6.5), 2) - 5.74) < .001);			// Incorrect calculation of length
	test(fabs(calcArea(calcLength(1.0, 1.2, 6.0, 6.1), calcLength(6.0, 6.1, 3.2, 6.5), calcLength(1.0, 1.2, 3.2, 6.5)) - 7.86) < .001);			// Incorrect calculation of area

	test(fabs(round_off(calcLength(1.2, 1.2, 7.6, 4.3), 2) - 7.11) < .001);			// Incorrect calculation of length
	test(fabs(round_off(calcLength(7.6, 4.3, 9.2, 3.4), 2) - 1.84) < .001);			// Incorrect calculation of length
	test(fabs(round_off(calcLength(1.2, 1.2, 9.2, 3.4), 2) - 8.30) < .001);			// Incorrect calculation of length
	test(fabs(calcArea(calcLength(1.2, 1.2, 7.6, 4.3), calcLength(7.6, 4.3, 9.2, 3.4), calcLength(1.2, 1.2, 9.2, 3.4)) - 5.36) < .001);			// Incorrect calculation of area

	test(fabs(round_off(calcLength(1.0, 1.0, 5.0, 5.0), 2) - 5.66) < .001);			// Incorrect calculation of length
	test(fabs(round_off(calcLength(5.0, 5.0, 9.0, 9.0), 2) - 5.66) < .001);			// Incorrect calculation of length
	test(fabs(round_off(calcLength(1.0, 1.0, 9.0, 9.0), 2) - 11.31) < .001);			// Incorrect calculation of length
	test(fabs(calcArea(calcLength(1.0, 1.0, 5.0, 5.0), calcLength(5.0, 5.0, 9.0, 9.0), calcLength(1.0, 1.0, 9.0, 9.0)) - 0.00) < .001);			// Incorrect calculation of area

	return 0;		
}

//************************  Function definitions  *************************
// Read the handout carefully for detailed description of the functions that you have to implement
double square(double& s, int x)
{
 s= s*s;
 return s = round_off(s,2);
}
double round_off(double x,int digits)

 {
   
  return round (x * pow(10., digits)) / pow(10., digits);
}

void getPoint(ifstream& inputFile, double& x, double& y )
{
  inputFile>> x>>y;
  x=round_off(x,1);
  y=round_off(y,1);
  return;

}

double calcLength(double x11,double y11,double x22,double y22)
{
x11=x22-x11;
y11=y22-y11; 


x11= square(x11,2);
y11= square(y11,2);

return round_off(sqrt((x11)+(y11)),10);
}
double semiPerimeter(double l1,double l2,double l3)
{
 l1=(1./2)*(l1+l2+l3);
 return round_off(l1,10);
}
double calcArea(double ab,double bc, double ca)
{

cout<<semiPerimeter(ab,bc,ca);
  return round_off(sqrt(semiPerimeter(ab,bc,ca)*(semiPerimeter(ab,bc,ca)-ab)*(semiPerimeter(ab,bc,ca)-bc)*(semiPerimeter(ab,bc,ca)-ca)),2);

}
void print_Distance(ofstream& outputFile,double x1,double y1,double x2, double y2,double DB)
{

  outputFile<<"The distance between ("<<x1<<","<<y1<<") and ("<<x2<<","<<y2<<") is "<<DB<<endl;

}