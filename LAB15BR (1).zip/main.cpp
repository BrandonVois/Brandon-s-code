#include<iostream>

// Include here the libraries that your program needs to compile
#include<cstdlib>
#include<ctime>
// Enter your function prototypes here
int randNumGen(int upper, int lower)	;
void getSeed(int& se,bool f);
void guessNumber(int numGuesses,bool f, int numg,int num);
using namespace std;

int main()
{
// Declare variable to get the seed specified by the user
int seed;
int num;
bool f;
f= false;
int numg;
int numguesses;
numguesses = 0;

// Display the title "Thank you for participating in the Guessing Game"
cout<<"Thank you for participating in the Guessing Game"<< endl<<endl;
// Display the instructions "If you want me to create a real random number enter 0 when prompted for the seed please."
cout<<"If you want me to create a real random number enter 0 when prompted for the seed please."<< endl;
// "Otherwise enter a number within the specified range please."
cout<<"Otherwise enter a number within the specified range please."<< endl<< endl;
// Call function getSeed() to get the seed from the user and assign it to the corresponding variable
getSeed(seed,f);

// If the user entered a zero (0) use srand(static_cast<int> (time(NULL))) to seed the random number generator.
// Otherwise use srand(seed) where seed represents the value entered by the user
num = randNumGen(100,1);

// Call function guessNumber() and pass it a random number within the range 1..100
guessNumber(numguesses, f, numg, num);

    
	
    return 0;
}

//************************  Function definitions  *************************
// Read the handout carefully for detailed description of the functions that you have to implement

// This function generates a random number within a specified range.
// It receives two whole numbers : the first one is the upper boundary and
// the second one is the lower boundary used to generate the random number.
// Returns the random number generated using expression 2) on my handout
int randNumGen(int upper, int lower)	
{										
	return (rand() % (upper - lower + 1)) + lower;
}




// This function prompts the user to enter a seed (a whole number) equal to zero (0) or 
// within the range 1000..4000. If the user enters a valid value the function returns 
// the value. Otherwise it keeps asking for the seed.
// Use a DO-LOOP to implement this function
void getSeed(int& se,bool f)
{
  do{
    cout<<"Enter a seed equal to 0 or in the range of 1000-4000: ";
    cin>>se;
    cout<<endl;
  
    if(se >= 1000 && se <= 4000)
    {f=true;
     }//procceed
   
    
    else if(se==0)
    {f=true;
    
    }//proceed
    else 
    {
       cout<<"Invalid input"<<endl;
      f=false;
      
    }
  }
  while(!f);
  {
   if (se==0)
   {
     srand(static_cast<int> (time(NULL)));
     f=false;

   }
   else if(se >= 1000 && se<=4000)
   {
     srand(se);
     f=false;
   }
  }
  
}



// This function receives a number and gives the user five chances to guess it.
// As the user provides a guess the program indicates whether the guess was correct
// or if it was too low or too high to help her/him.
// If the user runs out of guesses it shows her/him the number
// Use a FOR-LOOP to implement this function
void guessNumber(int numGuesses,bool f, int numg,int num)
{
  for(numGuesses=0;numGuesses<5; ++numGuesses)
{
   while(!f)
 {
    cout<<"Guess the number the computer randomly picked between 1 - 100: ";
 cin>> numg;
   if(num == numg)
 {
   cout<<"You guessed right, you win!"<<endl;
   system("pause");
   system("cls");
   f=true;
 
   }
   else if(num < numg)
   {
   cout<<"Your guess is too high"<<endl;
   f= false;
   }
   else if (num>numg)
   {
   cout<<"Your guess is too low"<<endl;
   f=false;
 
 }
  numGuesses++;
   if(numGuesses == 5)
   {cout<<"Sorry you have lost, the number was "<<num<<endl;
   break;}
  
     
   
  
   
 }
 
   }

}