#include <math.h>
#include <iostream>

using namespace std;

class square
{
public:
    void setSide(int s);
    int getSide();
    square();
    square(int s);
    int plus(square sq);
    int minus(square sq);
    int increaseBy(int factor);
    bool equalTo(square sq);
    int area();
    int perimeter();

private:
    int side;
};

void square::setSide(int s)
{
    side = s;
}

int square::getSide() 
{
    return side;
}

square::square()
 {
    side = 0;
}

square::square(int s) 
{
    side = s;
}

int square::plus(square sq) 
{
    return area() + sq.area();
}

int square::minus(square sq) 
{
return area() - sq.area();
}

 int square :: increaseBy(int factor)
 {
 return side*factor;
 }


bool square::equalTo(square sq) {

 if (side == sq.side) {
    return true;
    }
    else {
    return false;
    }

}

int square::area() 
{
    return side * side;
}

int square::perimeter() 
{
    return side+side+side+side;

}