#include <iostream>
#include <fstream>
using namespace std;

// include the header file for squares
/*your code here*/


double ademup(double * X, int start, int end)
{
  double total;
  for(int i=start; i <=end;i++ )
  {
    total=X[i]+ total;

  }
 return total;

}


int main() {

double*  B;
B= new double[4];
B[0]=5;
B[1]=15;
B[2]=3;
B[3]=2;

cout<<ademup(B, 0, 4);



  
}