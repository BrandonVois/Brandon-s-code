// Semester: <This semester, like: Spring 2012>
// CSCI/CMPE 1370 Instructor: <Your lecture instructor's name>
//
// This program creates a simulated player who takes one turn in the
// Pig dice game. The simulated player keeps rolling the die until
// the total for the turn is 20 or greater, or until a 1 is rolled.
// If a 1 is rolled, the player's score for the turn is 0. Otherwise
// the player's score is the sum of the rolls for the turn.
//
/////////////////////////////////////////////////////////////////////

#include<iostream>
#include<cstdlib>
#include<time.h>

using namespace std;

int randNumGen(int upper, int lower);	// function prototype

int main()
{
    int roll; // The value of the die roll
    int total_turn = 0; // Player's score for this turn

    // Seed the random number generator
    srand(static_cast<int> (time(NULL))); 

    
    /////////////////////////////////////////
    // Start of your code
    
    
    // Use a while loop to roll the die until the total turn number is 
    // 20 or greater, or until a 1 is rolled. if a 1 is rolled the 
    // player gets a 0 for the turn.
	// Call function randNumGen() to generate a number within the range 1..6
	// to simulate the rolling of the die
  while(total_turn <=20)
  {
    cout<<"Its the computers turn to roll"<< endl;
    roll=randNumGen(6, 1);
    if(roll == 2 || roll == 3 || roll == 4 || roll==5 || roll == 6)
    {
    cout<<"Computer rolled a: " <<roll<<endl;
    total_turn= roll+ total_turn;
    cout<<"Current total of the turn: "<<total_turn<< endl;
    }
    else
    {
      total_turn = 0;
      cout<<"Computer rolled a: " <<roll<<endl;
      cout<<"Current total of the turn: "<<total_turn<< endl;
     break;
    }
  }
   
cout<<"Computer has completed its turn"<< endl;
cout<<"Computer got "<< total_turn<<" for its turn" ;

  
	
	
    
    
    
    //output the number of points the simulated player got for the turn.

    
    
    
    // End of your code
    /////////////////////////////////////////

    system("pause");
    return 0;

}//close main()

// function definition
int randNumGen(int upper, int lower)	// function heading
{										// function body
	return (rand() % (upper - lower + 1)) + lower;
}