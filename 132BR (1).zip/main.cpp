#include<iostream>
#include <cstdlib>
#include <ctime>

// Include the libraries that you need for the program to compile



using namespace std;

// Enter your prototypes here
 int randNumGen(int ya,int xa);


int main()
{
// Declare variable number to hold a random (whole) number
int num;

// Declare variable guess to hold the (whole) number guessed by the user
int numg;

// Declare variable correct that holds boolean values and initialize it to false
bool f;
f= false;

// Declare variable numGuesses to hold the (whole) number used to keep track of the
// number of guesses made by the user and initialize it to zero
int numGuesses;
numGuesses = 0;

// Seed the random generator
 srand (time(NULL));

// Call function randNumGen() to generate a random number between 1 and 100 and
// assign the value returned to number
num=randNumGen(100,1);

// Use a COUNTER-CONTROLLED combined with a FLAG-CONTROLLED LOOP to let the user guess a
// number until her/him guesses it correctly or uses the five chances allowed to guess
// the number generated above
// As the user provides a guess the program indicates whether the guess was correct or
// if it was too low or too high to help her/him. If the user runs out of guesses it shows
// her/him the number
while(numGuesses<5)
{
    while(!f)
  {
     cout<<"Guess the number the computer randomly picked between 1 - 100: ";
  cin>> numg;
    if(num == numg)
  {
    cout<<"You guessed right, you win!"<<endl;
    system("pause");
    system("cls"); 
    f=true;

    }
    else if(num < numg)
    {
    cout<<"Your guess is too high"<<endl;
    f= false;
    }
    else if (num>numg)
    {
    cout<<"Your guess is too low"<<endl;
    f=false;

  }
    ++numGuesses;
    if(numGuesses == 5)
    cout<<"Sorry you have lost, the number was "<<num<<endl;
  }
 

    }






	
    return 0;
}

// This function generates a random number within a specified range.
// It receives two whole numbers : the first one is the upper boundary and
// the second one is the lower boundary used to generate the random number.
// Returns the random number generated using the expression:
//    rand() % (upper - lower + 1)) + lower

 int randNumGen(int ya,int xa)
 {
   return rand() % (ya - xa + 1) + xa;
 }
