//******************************************************************************
// Team #          CSCI/CMPE 1370      Spring 2021                    Homework # 1
// Brandon Rubio
// First and Last Name
//  It converts pesos and euros into dollars and //then adds up the converted amount. 
// 
//******************************************************************************

#include <iostream>				// to be able to use cout
#include <typeinfo>				// to be able to use operator typeid
#include <iomanip>
#include <cmath>

// Include here all the libraries that you need for your program to compile



using namespace std;

// Ignore this; it's a little function used for making tests
inline void _test(const char* expression, const char* file, int line)
{
	cerr << "test(" << expression << ") failed in file " << file;
	cerr << ", line " << line << "." << endl << endl;
}
// This goes along with the above function...don't worry about it
#define test(EXPRESSION) ((EXPRESSION) ? (void)0 : _test(#EXPRESSION, __FILE__, __LINE__))

int main()
{
// Enter here your algorithm as a series of MEANINGFUL steps.
// Write below EACH step of the algorithm the C++ statement that implements it.
double const DOL2MEX = 20.09;
double const DOL2EURO = 0.83;
double pesos;
double euros;
double pesodoublef;
double eurodoublef;
double kekp;
double keke;
double dtotal;
double centt;
int wholedollarsp;
int centdollarsp;
int wholedollarse;
int centdollarse;
int wholetotal;
int centtotal;

cout<<"Mexican Peso and Euro to U. S Dollar converter"<<endl;
cout<< "Please enter the amount of Pesos: ";
cin>>pesos;
cout<< "Please enter the amount of Euros: " ;
cin>>euros;
pesodoublef = pesos /  DOL2MEX;
eurodoublef = euros /DOL2EURO;
pesodoublef= round (pesodoublef * 100.0) / 100.0;
eurodoublef = round (eurodoublef * 100.0) / 100.0;
wholedollarsp = pesos / DOL2MEX; //Whole dollar amount of the pesos converted to dollar
pesodoublef = pesos / DOL2MEX;   //full number of dollar converted from peso(with decimals)
kekp=pesodoublef - wholedollarsp; //full number with decimal - wholenumber
kekp= kekp*100; //decimal times a hundred to get full number
centdollarsp = kekp;   //cents of converted pesos in whole number
wholedollarse = euros /DOL2EURO; //whole dollar amount of euro converted to dollar
eurodoublef = euros /DOL2EURO; //decilal amount of euro convetred to dolalr
keke=eurodoublef - wholedollarse; //decimal amount of euro converted to dollar for the cents
keke = keke * 100; //cents multiplied by 100 a to get a whole number
dtotal= pesodoublef + eurodoublef;//total in double digits

centdollarse = keke; //eqatuing centdoollarse to keke the whole number of cents
wholetotal = dtotal; //getting the whole total of eqaution
centt = (dtotal-wholetotal) * 100 ;
centtotal = centt; //getting the cent total of the converted equation



cout << fixed << setprecision(2);

cout<<  "\n\n pesos: "<<pesos<<"$     "<<wholedollarsp<< " US Dollars with " <<centdollarsp<< "   cents"<<endl;
cout<< "\n\n euros: "<<euros<<"$      "<< wholedollarse <<" US Dollars with "<< centdollarse << " cents" <<endl;
cout<< " \n\n Total:          "<< wholetotal <<" US Dollars with " <<centtotal<<" cents"<<endl ;





// ----------------------------- Your code ends here -----------------------------

// Do NOT remove or modify the following statements

// To clear the screen use:
//system("cls");		// for Windows (Visual Studio)
//system("clear");		//for Unix/Linux/MacOS (repl.it)

// To pause the execution of the program you can use the following three statements:
	cout << "\nPress Enter to continue ...";
	cin.ignore(1000, '\n');
	cin.get();

	cout << endl << "Testing your solution" << endl << endl;
	test(typeid(DOL2MEX) == typeid(1.));			// Incorrect data type used for DOL2MEX
	test(typeid(DOL2EURO) == typeid(1.));			// Incorrect data type used for DOL2EURO
	test(typeid(pesos) == typeid(1.));				// Incorrect data type used for pesos
	test(typeid(euros) == typeid(1.));				// Incorrect data type used for euros
	test(typeid(wholedollarsp) == typeid(1));		// Incorrect data type used for wholedollarsp
	test(typeid(centdollarsp) == typeid(1));		// Incorrect data type used for centdollarsp
	test(typeid(wholedollarse) == typeid(1));		// Incorrect data type used for wholedollarse
	test(typeid(centdollarse) == typeid(1));		// Incorrect data type used for centdollarse
	test(typeid(wholetotal) == typeid(1));			// Incorrect data type used for wholetotal
	test(typeid(centtotal) == typeid(1));			// Incorrect data type used for centtotal
	if (pesos == 120.0 && euros == 120.0)			// Does not pass test 1
	{
		test(wholedollarsp == 5 && centdollarsp == 97);
		test(wholedollarse == 144 && centdollarse == 58);
		test(wholetotal == 150 && centtotal == 55);
	}
	if (pesos == 188.25 && euros == 130.00)				// Does not pass test 2
	{
		test(wholedollarsp == 9 && centdollarsp == 37);
		test(wholedollarse == 156 && centdollarse == 63);
		test(wholetotal == 166 && centtotal == 0);
	}
	if (pesos == 1326.35 && euros == 13.33)			// Does not pass test 3
	{
		test(wholedollarsp == 66 && centdollarsp == 02);
		test(wholedollarse == 16 && centdollarse == 6);
		test(wholetotal == 82 && centtotal == 8);
	}
	if (pesos == 240.19 && euros == 43.29)				// Does not pass test 4
	{
		test(wholedollarsp == 11 && centdollarsp == 96);
		test(wholedollarse == 52 && centdollarse == 16);
		test(wholetotal == 64 && centtotal == 12);
	}
	return 0;
}


//{
   // double initialAmount = 42800.13;
    //double fractionalPart = initialAmount - floor(initialAmount);
    //cout<<int(initialAmount)<<"\n"<<fractionalPart<<"\n";

//}