#include <iostream>				// to use cin and cout
#include <typeinfo>				// to be able to use operator typeid

// Include here the libraries that your program needs to compile
#include<string>
#include <iomanip>
#include<cmath>

using namespace std ;

// Ignore this; it's a little function used for making tests
inline void _test(const char* expression, const char* file, int line)
{
	cerr << "test(" << expression << ") failed in file " << file;
	cerr << ", line " << line << "." << endl << endl;
}
// This goes along with the above function...don't worry about it
#define test(EXPRESSION) ((EXPRESSION) ? (void)0 : _test(#EXPRESSION, __FILE__, __LINE__))

// Insert here the prototypes of the functions
double square (double s);
double round_off(double x, int digits);
double volume_cone(int r, int h);
void print_data(string name, int r, int h, double a);
// Declare a global constant variable called PI that holds value 3.141592
double const PI = 3.141592;

int main()
{
// Declare a variable named name that holds text
string name;

// Declares variables named height and radius that hold whole numbers
int height, radius,l;
// Declare a variable named volume that holds double precision real numbers
double volume;

// Prompts the user "May I get your first name please?: "
cout<<"May I get your first name? ";
// Read the value from the keyboard and stores it in name
cin>>name;
// Prompt the user "Thanks ", name, " , now enter radius and height of the cone please: "
cout<<"Thanks "<<name<<endl;
cout<<"Enter the radius and height of the cone please: ";
// Read the values from the keyboard and stores them in radius and height respectively
cin>>radius>>height;
// Call function volume_cone() to calculate the volume of the cone and assign the result to volume 
volume= volume_cone(radius, height);
// Call function print_data() to print the values entered by the user and the volume of the cone
print_data( name, radius, height, volume);



	//system("pause");

// Do NOT remove or modify the following statements
	cout << endl << "Testing your solution" << endl << endl;
	test(typeid(PI) == typeid(1.));							// Incorrect data type used for PI
	test(PI == 3.141592);									// Incorrect value used for PI
	test(typeid(name) == typeid(string));					// Incorrect data type used for name
	test(typeid(height) == typeid(1));						// Incorrect data type used for height
	test(typeid(radius) == typeid(1));						// Incorrect data type used for radius
	test(typeid(volume) == typeid(1.));						// Incorrect data type used for volume
	test(fabs(volume_cone(3,5) - 47.124) < 0.0001);			// Incorrect rounding of volume
	test(fabs(volume_cone(3, 4) - 37.699) < 0.0001);		// Incorrect rounding of volume

	//system("pause");
	return 0;
}


//************************  Function definition  *************************
// Read the handout carefully for detailed description of the functions that you have to implement

// Calculates the square of the value received
double square ( double s)
 {
   double s_quared;
   s_quared =  s * s;
   return s_quared ;
 }

// Calculates the volume of the cone using the formula 1 / 3 x Pi x radius^2 x height
 double volume_cone(int r, int h)
 {
   double r_squared;
   r_squared = square(r);
   h = (1./3.) * (PI) * r_squared * h;
  return round_off(h, 3);
   
 }


// Rounds the value received in the first parameter to the number of digits received in the second parameter
double round_off(double x,int digits)

 {
   
  return round (x * pow(10.0, digits)) / pow(10.0, digits);
}



// Prints the volume of the cone
void print_data(string n, int r, int h, double a)
{
	cout << fixed << setprecision(3);
  cout<<"Ok "<<n;
	cout << "\nFor a radius: " << r << " and a height: " << h << " The cone's volume is " << a << endl << endl;
}

