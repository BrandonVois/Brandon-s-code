/////////////////////////////////////////////////////////////////////
// 
// Name: <Brandon Rubio>
// Date: <4/17/2021>
// Class: <Your class number and section number, like: CSCI 1370.02>
// Semester: <This semester, like: Spring 2012>
// CSCI 1370 Instructor: <Your lecture instructor's name>
//
// This program gets the number of votes for each candidate in
// an election from a file. It then finds the percentage of votes
// received byeach candidate, and reports the winner of the election.
//
/////////////////////////////////////////////////////////////////////

#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
using namespace std;

int sumList(const int list[], int size,int counter);
int indexOfMax(int list[], int size);
// This function gets the results from the file and returns them in the corresponding
void getElectionData(ifstream & iFile, string candidates[], int ballots[], int & count);
void printResults(const string candidates[], const int ballots[], int count, int totalBallots,int winner);
const int NUM_CANDIDATES = 10; // The number of candidates

int main()
{
	ifstream inFile;
	string names[NUM_CANDIDATES]; // The names of the candidates
	int votes[NUM_CANDIDATES]; // The number of votes received by each candidate
	int totalVotes; // The total number of votes received by all candidates
	int max;	// number of candidates processed
  int winner;

	inFile.open("votingresults.txt");
	if (!inFile)
	{
		cout << "File not found!" << endl << endl;
		system("pause");
		return 1;
	}


	
    ///////////////////////////////
    // Start of your code


    // Get the candidates' names and number of votes each received
    // Assume the user enters valid input (just call the getElectionData() function)
getElectionData(inFile, names, votes, max);

	
    // Calculate the total number of votes received by all candidates
    // (call the sumList() function)
   totalVotes =sumList(votes, totalVotes, max);
   
	
  winner =indexOfMax(votes, max);	

    // Print each candidate's name, the number of votes she received,
    // and the percent of votes the candidate received
	// (just call the printResults() function)
  printResults(names, votes, max , totalVotes,winner);

	
    // End of your code in the main function
    // Don't forget to complete the functions below
    ///////////////////////////////

    return 0;
}

//
// Returns the sum of the numbers in the given array
//
// WRITE THE BODY OF THIS FUNCTION
//
int sumList(const int list[], int size,int counter)
{
  int x;
  
  for(x=1;x<counter;++x)
  {

    size=list[x]+size;
  
    
  }


return size;
}

//
// Returns the index of the largest value in the given array (not the largest
// value, but the index of it)
//
// WRITE THE BODY OF THIS FUNCTION
//
int indexOfMax(int list[], int size)
{
  int i;
 int n
 for(i = 1;i<size; ++i)
    {
      
        if(list[0] < list[i])
       list[0]=list[i];
     
          
    }

return n;
}

// Gets the names of the candidates and the votes they got from the file and returns
// them in the corresponding arrays. It also returns the number of rows in the file that
// were processed Makes sure it never goes over the array capacity when loading the data
// in the arrays
//
// WRITE THE BODY OF THIS FUNCTION
//
void getElectionData(ifstream & iFile, string candidates[], int ballots[], int & count)
{
  count=0;
  while(iFile)
  {
    ++count;
    iFile>>candidates[count]>>ballots[count];
    

  }

}

// Receives the candidates names and the quantity of votes they got, the number of elements
// in the arrays to be processed, and the total number of votes so they can be displayed as
// shown in the file with the problem statement
// Must call the indexOfMax function() to find the array index of the candidate with the
// largest number of votes
//
// WRITE THE BODY OF THIS FUNCTION
//
void printResults(const string candidates[], const int ballots[], int count, int totalBallots,int winner)

{
  cout << setw(10) << " CANDIDATE " << setw(8) << "NUM VOTES" << "   % of votes" << endl << endl;
  int x;
  
  for(x=1;x<count;++x)
  {
 
  cout << setprecision(4);
   cout << setw(10) << candidates[x]<< setw(8) << ballots[x] <<"        "<< (static_cast<double>(ballots[x])*100.)/static_cast<double>(totalBallots) << endl;
  }
  
      
  
  cout<<"The winner is "<<candidates[winner];
  
}
