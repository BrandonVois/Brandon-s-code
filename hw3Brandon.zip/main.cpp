//******************************************************************************
// Team #14 CSCI 1370 Spring 2021 Homework # 3
// Jose Gonzalez
// Brandon Rubio
// Using your own words, write here a description of what the program does.
//Suntracts and adds fractions with a fashionable interface
//******************************************************************************

//PROGRAM THAT WORKS WITH Rational NUMBERS
// Shows a menu that lets the user define the operation to be executed

#include <iostream>			// to use cin and cout
#include <typeinfo>				// to be able to use operator typeid

// Include the libraries that your program needs to compile here

#include <sstream>

using namespace std;

// Include the function prototypes here
void reduce(int& num, int& den);

void DisplayRational(int& num, int& den);

void SubtractRational(int& anum, int& aden, int num1, int den1, int num2, int den2);

void AddRational(int& anum, int& aden, int num1, int den1, int num2, int den2);

void GetRational(int& num, int& den, char slash);

void showMenu(char& inputletter);


// Ignore this; it's a little function used for making tests
inline void _test(const char* expression, const char* file, int line)
{
    cerr << "test(" << expression << ") failed in file " << file;
    cerr << ", line " << line << "." << endl << endl;
}
// This goes along with the above function...don't worry about it
#define test(EXPRESSION) ((EXPRESSION) ? (void)0 : _test(#EXPRESSION, __FILE__, __LINE__))

int main()
{
    // Start entering your code here ----------------------------------------
    int num1, den1, num2, den2, anum = 0, aden = 0;
    char inputletter;
    char yn;
    char slash=' ';
    int loopbreaker;
    bool yes;
    yes = true;


    loopbreaker = 1;

    while (loopbreaker == 1)
    {
        showMenu(inputletter);
        yes=true;
        if (inputletter == 'A' || inputletter == 'a')
        {
            while (yes)
            {
                system("cls");
                cout << "Addition of rational numbers" << endl << endl;
                GetRational(num1, den1, slash);

                if (den1 == 0)
                {
                    cout << "No zero in the denominator allowed, do first fraction again" << endl;
                    GetRational(num1, den1, slash);

                }
                GetRational(num2, den2, slash);

                if (den2 == 0)
                {
                    cout << "No zero in the denominator allowed, do second fraction again" << endl;
                    GetRational(num2, den2, slash);
                }
                AddRational(anum, aden, num1, den1, num2, den2);
                reduce(anum, aden);

                cout << "The result of "<< num1 << "/" << den1 << " + " << num2 << "/" << den2;
                cout << " = "; DisplayRational(anum, aden);
                cout << "\nDo you want more additions (Y/N) ";
                cin >> yn;

                if (yn == 'Y' || yn == 'y')
                {
                    yes = true;
                }
                else if (yn == 'N' || yn == 'n')
                {
                    yes = false;
                    system("cls");
                }

            }

        }
        else if (inputletter == 'S' || inputletter == 's')
        {
            while (yes)
            {
                system("cls");
                cout << "Subtraction of rational numbers" << endl << endl;
                GetRational(num1, den1, slash);

                if (den1 == 0)
                {
                    cout << "No zero in the denominator allowed, do first fraction again" << endl;
                    GetRational(num1, den1, slash);

                }
                GetRational(num2, den2, slash);

                if (den2 == 0)
                {
                    cout << "No zero in the denominator allowed, do second fraction again" << endl;
                    GetRational(num2, den2, slash);
                }
                SubtractRational(anum,  aden, num1, den1, num2, den2);

                cout << "The result of " << num1 << "/" << den1 << " - " << num2 << "/" << den2;
                cout << " = "; DisplayRational(anum, aden);
                cout << "\nDo you want more subtractions (Y/N) ";
                cin >> yn;

                if (yn == 'Y' || yn == 'y')
                {
                    yes = true;
                }
                else if (yn == 'N' || yn == 'n')
                {
                    yes = false;
                    system("cls");
                }
            }
        }
        else if (inputletter == 'Q')
        {
            loopbreaker = 2;
        }
        else
        {
            system("cls");
        }


    }



    
	cout << endl;
	// This is to pause the execution of the program
	cout << "Press Enter to continue ...";
	cin.sync();
	cin.ignore(100, '\n');
	cin.get();

						// Do NOT remove or modify the following statements
	cout << endl << "Testing your solution" << endl << endl;
	int num, den;
	num = 4; den = 3;
	reduce(num, den);
	test(num == 4 && den == 3);								// Incorrect reducing of the fraction
	num = 12; den = 3;
	reduce(num, den);
	test(num == 4 && den == 1);								// Incorrect reducing of the fraction
	num = 3; den = 12;
	reduce(num, den);
	test(num == 1 && den == 4);								// Incorrect reducing of the fraction
	num = -3; den = 12;
	reduce(num, den);
	test(num == -1 && den == 4);							// Incorrect reducing of the fraction
	num = -63; den = 15;
	reduce(num, den);
	test(num == -21 && den == 5);							// Incorrect reducing of the fraction
	num = -1024; den = 127;
	reduce(num, den);
	test(num == -1024 && den == 127);						// Incorrect reducing of the fraction

	AddRational(num, den, 1, 2, 2, 4);
	test(num == 1 && den == 1);								// Incorrect addition of the fractions
	AddRational(num, den, 1, 3, 3, 4);
	test(num == 13 && den == 12);							// Incorrect addition of the fractions
	AddRational(num, den, 9, 5, 2, 5);
	test(num == 11 && den == 5);							// Incorrect addition of the fractions
	AddRational(num, den, 1, 3, 3, 18);
	test(num == 1 && den == 2);								// Incorrect addition of the fractions
	AddRational(num, den, 1, 7, 3, 9);
	test(num == 10 && den == 21);							// Incorrect addition of the fractions
	AddRational(num, den, 3, 7, 6, 9);
	test(num == 23 && den == 21);							// Incorrect addition of the fractions

	SubtractRational(num, den, 1, 2, 2, 4);
	test(num == 0 && den == 1);								// Incorrect subtraction of the fractions
	SubtractRational(num, den, 1, 3, 3, 4);
	test(num == -5 && den == 12);							// Incorrect subtraction of the fractions
	SubtractRational(num, den, 9, 5, 2, 5);
	test(num == 7 && den == 5);								// Incorrect subtraction of the fractions
	SubtractRational(num, den, 1, 3, 3, 18);
	test(num == 1 && den == 6);								// Incorrect subtraction of the fractions
	SubtractRational(num, den, 1, 1, 75, 12);
	test(num == -21 && den == 4);							// Incorrect subtraction of the fractions
	SubtractRational(num, den, 6, 9, 3, 7);
	test(num == 5 && den == 21);							// Incorrect subtraction of the fractions

															// This is to pause the execution of the program
	cout << "Press Enter to continue ...";
	cin.sync();
	cin.ignore(100, '\n');
	cout << endl;
	return 0;
}

// Define your functions below this line please



    // Stop entering your code here ----------------------------------------


  

// Define your functions below this line please
//---------------------------------------------
void showMenu(char& inputletter)
{
    cout << "Rational Number Calculator" << endl << endl;
    cout << "(A)dd" << endl;
    cout << "(S)ubtract" << endl;
    cout << "(Q)uit" << endl;
    cout << "Enter your option: ";
    cin >> inputletter;
}

void GetRational(int& num, int& den, char slash)
{
    cout << "Please enter a fraction (n/d): ";
    cin >> num >> slash >> den;


}

void reduce(int& num, int& den)
{
    int a = abs(num);
    int b = abs(den);
    int r = a % b;
    
    while (r != 0)
    {
        a = b;
        b = r;
        r = a % b;
    }

    num /= b;
    den /= b;
}

void AddRational(int& anum, int& aden, int num1, int den1, int num2, int den2)
{
    anum = (num1 * den2) + (num2 * den1);
    aden = (den1 * den2);
}

void DisplayRational(int& num, int& den)
{
    if (num == den)
    {
      
        cout << "1";
    }

    else if (den != 1)
    {
        cout << num << "/" << den;
    }

    else
        cout << num;
}

void SubtractRational(int& anum, int& aden, int num1, int den1, int num2, int den2)
{
 
    anum = (num1 * den2) - (num2 * den1);
    aden = (den1 * den2);
}